<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <p>تمامی حقوق محفوظ است &copy; 2025 | طراحی شده با ❤️</p>
            <ul class="footer-links">
                <li><a href="aboutme.php">درباره ما</a></li>
                <li><a href="connectme.php">تماس با ما</a></li>
                <li><a href="wablog.php">وبلاگ</a></li>
            </ul>
            <div class="social-icons">

            </div>
        </div>
    </div>
</footer>

<!-- لینک به FontAwesome برای آیکون‌ها -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="footer.css">
